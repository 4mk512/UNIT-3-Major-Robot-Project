#Developing Pi Camera Code
from picamera import PiCamera
from time import sleep

# My advice is to go to this site, if you would like to use the Pi Cam
# https://www.hackster.io/ruchir1674/video-streaming-on-flask-server-using-rpi-ef3d75