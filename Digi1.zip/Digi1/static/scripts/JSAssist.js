//Javascript for JSON and AJAX stuff. For now getting degree of rotation for robot

/*function getbatteryvoltage(){
    return jQuery.ajax('/getbatteryvoltage','GET',sendbatteryvoltage(data),sendbatteryvoltage(0));
} */


setInterval(getvoltage, 1000,'/getbatteryvoltage');
setInterval(console.log("WHY"),5000);

function getvoltage(ReqRoute){
    {
    $.ajax({
        url: ReqRoute,
        method: 'POST',
        //beforeSend: function(){console.log(url,method)}, 
        success: function(data){sendbatteryvoltage(data); console.log(data)},
        error: function(data){sendbatteryvoltage(null);console.log(data)},
    })
}
}

function sendbatteryvoltage(voltage){
    if (voltage != null){
        var voltagestr = JSON.stringify(voltage)
        var newtext = "Voltage = " + voltagestr;
        console.log(voltage)
        console.log(newtext)
        document.getElementById('voltage').innerHTML = newtext;
    }
    else{
        document.getElementById('voltage').innerHTML = "ERROR";
    }
}
